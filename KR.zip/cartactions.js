function addToCart(element)
{
  let title = element.getElementsByClassName("info")[0].getElementsByClassName("title")[0].innerHTML;
  let price = element.getElementsByClassName("info")[0].getElementsByClassName("price")[0].getElementsByTagName("strong")[0].innerHTML;
  let imagePath = element.getElementsByClassName("img")[0].getElementsByTagName("a")[0].getElementsByTagName("img")[0].src;
  if (sessionStorage.getItem("cart") == null)
  {
    let goods = [{"title":title, "price":price, 'number':1, 'image':imagePath}];
    sessionStorage.setItem("cart",JSON.stringify(goods));
  }
  else
  {
    goods = JSON.parse(sessionStorage.getItem("cart"));
    let inArray = false;
    for (let i=0;i<goods.length;i++)
    {
      if (goods[i]['title'] == title)
      {
        goods[i]['number']+=1;
        inArray = true;
        break;
      }
    }
    if (inArray == false)
    {
      goods.push({"title":title, "price":price, "number":1, 'image':imagePath});
    }
      sessionStorage.removeItem('cart');
      sessionStorage.setItem("cart",JSON.stringify(goods));
  }
}
